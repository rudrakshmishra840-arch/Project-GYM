"use client"

import { useEffect, useRef, useState } from 'react'
import { Target, Heart, Zap, Trophy } from 'lucide-react'

function AnimatedCounter({ end, duration = 2000, suffix = '' }: { end: number; duration?: number; suffix?: string }) {
  const [count, setCount] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.5 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isVisible) return

    let startTime: number
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)
      setCount(Math.floor(progress * end))
      if (progress < 1) {
        requestAnimationFrame(step)
      }
    }
    requestAnimationFrame(step)
  }, [isVisible, end, duration])

  return (
    <span ref={ref} className="text-4xl lg:text-5xl font-bold text-[#ff5722]">
      {count}{suffix}
    </span>
  )
}

const stats = [
  { value: 500, suffix: '+', label: 'Clients Trained' },
  { value: 5, suffix: '+', label: 'Years Experience' },
  { value: 10, suffix: '+', label: 'Expert Trainers' },
  { value: 95, suffix: '%', label: 'Success Rate' },
]

const features = [
  { icon: Target, title: 'Goal Focused', description: 'Personalized plans tailored to your specific fitness goals' },
  { icon: Heart, title: 'Health First', description: 'Safe training methods that prioritize your wellbeing' },
  { icon: Zap, title: 'High Energy', description: 'Dynamic workouts that keep you motivated' },
  { icon: Trophy, title: 'Results Driven', description: 'Proven track record of transformations' },
]

export default function AboutSection() {
  return (
    <section id="about" className="py-20 lg:py-32 bg-[#0a0a0a] relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#ff5722]/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Image */}
          <div className="relative">
            <div className="relative">
              {/* Main Image */}
              <div className="relative overflow-hidden rounded-3xl">
                <img 
                  src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=2070&auto=format&fit=crop"
                  alt="Personal training session"
                  className="w-full h-[500px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              </div>
              
              {/* Floating Stats Card */}
              <div className="absolute -bottom-8 -right-8 bg-[#ff5722] rounded-2xl p-6 shadow-2xl">
                <p className="text-4xl font-bold text-white">5+</p>
                <p className="text-white/80 text-sm">Years of Excellence</p>
              </div>
              
              {/* Decorative Element */}
              <div className="absolute -top-4 -left-4 w-24 h-24 border-l-4 border-t-4 border-[#ff5722]" />
            </div>
          </div>

          {/* Right Column - Content */}
          <div className="space-y-8">
            {/* Section Tag */}
            <div className="inline-block">
              <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
                About Us
              </span>
              <div className="w-12 h-1 bg-[#ff5722] mt-2" />
            </div>

            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Give Shape To <br />
              <span className="text-gradient">Your Body</span>
            </h2>

            <p className="text-gray-400 text-lg leading-relaxed">
              At Project Fitness Gym, we help you build strength, confidence, and lasting habits. 
              With expert coaches and proven programs, we guide you toward your best shape. 
              Our state-of-the-art facility in Lucknow is designed to inspire and motivate you every step of the way.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3 group">
                  <div className="w-12 h-12 rounded-xl bg-[#ff5722]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#ff5722]/20 transition-colors duration-300">
                    <feature.icon className="w-6 h-6 text-[#ff5722]" />
                  </div>
                  <div>
                    <h4 className="text-white font-semibold mb-1">{feature.title}</h4>
                    <p className="text-gray-500 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center p-6 rounded-2xl bg-[#111] border border-gray-800 hover:border-[#ff5722]/50 transition-colors duration-300">
              <AnimatedCounter end={stat.value} suffix={stat.suffix} />
              <p className="text-gray-400 mt-2">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
