"use client"

const stats = [
  { label: 'Fitness Training', percentage: 95 },
  { label: 'Cardio Training', percentage: 82 },
  { label: 'Body Building', percentage: 88 },
]

export default function TrainersSection() {
  return (
    <section className="py-20 lg:py-32 bg-[#0a0a0a] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-3xl">
              <img 
                src="https://images.unsplash.com/photo-1571388208497-71bedc66e932?q=80&w=2072&auto=format&fit=crop"
                alt="Personal trainer with client"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />
            </div>
            
            {/* Decorative Element */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border-r-4 border-b-4 border-[#ff5722]" />
          </div>

          {/* Right Column - Content */}
          <div className="space-y-8">
            {/* Section Tag */}
            <div className="inline-block">
              <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
                Expert Team
              </span>
              <div className="w-12 h-1 bg-[#ff5722] mt-2" />
            </div>

            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Get Stronger And Fitter With Our <span className="text-gradient">Experienced Trainers</span>
            </h2>

            <p className="text-gray-400 text-lg leading-relaxed">
              Build strength and confidence with support from our highly trained team. 
              We dedicate our skills and expertise to your success, ensuring you achieve 
              your fitness goals safely and effectively.
            </p>

            {/* Progress Bars */}
            <div className="space-y-6">
              {stats.map((stat, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="text-white font-medium">{stat.label}</span>
                    <span className="text-[#ff5722] font-semibold">{stat.percentage}%</span>
                  </div>
                  <div className="h-3 bg-[#1a1a1a] rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-[#ff5722] to-[#ff8a65] rounded-full transition-all duration-1000"
                      style={{ width: `${stat.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
