"use client"

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { ChevronRight, Play } from 'lucide-react'

interface HeroSectionProps {
  onBookConsultation: () => void
}

export default function HeroSection({ onBookConsultation }: HeroSectionProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
          alt="Gym interior"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 gradient-overlay" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-[#ff5722]/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#ff5722]/5 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Text Content */}
          <div className={`space-y-8 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-[#ff5722]/20 border border-[#ff5722]/30 rounded-full px-4 py-2">
              <span className="w-2 h-2 bg-[#ff5722] rounded-full animate-pulse" />
              <span className="text-sm font-medium text-[#ff5722]">{"#1 FITNESS CENTER IN LUCKNOW"}</span>
            </div>

            {/* Headline */}
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight">
              <span className="text-white block">TRANSFORM</span>
              <span className="text-white block">YOUR BODY.</span>
              <span className="text-gradient block">TRANSFORM</span>
              <span className="text-gradient block">YOUR LIFE.</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg sm:text-xl text-gray-300 max-w-xl leading-relaxed">
              Join Project Fitness Gym with certified trainers & personalized plans. 
              Start your transformation journey today.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={onBookConsultation}
                className="bg-[#ff5722] hover:bg-[#e64a19] text-white font-bold px-8 py-6 text-lg rounded-full transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(255,87,34,0.5)] group"
              >
                Book Free Consultation
                <ChevronRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-6 text-lg rounded-full transition-all duration-300 group"
                onClick={() => document.getElementById('membership')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                View Membership
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-8 border-t border-white/10">
              <div>
                <p className="text-4xl font-bold text-[#ff5722]">500+</p>
                <p className="text-sm text-gray-400">Happy Clients</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-white">10+</p>
                <p className="text-sm text-gray-400">Expert Trainers</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-white">5+</p>
                <p className="text-sm text-gray-400">Years Experience</p>
              </div>
            </div>
          </div>

          {/* Right Column - Feature Image */}
          <div className={`hidden lg:block relative transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-[#ff5722]/20 to-transparent rounded-3xl blur-2xl" />
              <img 
                src="https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?q=80&w=2070&auto=format&fit=crop"
                alt="Fitness Training"
                className="relative rounded-3xl shadow-2xl w-full max-w-lg mx-auto"
              />
              {/* Floating Card */}
              <div className="absolute -bottom-6 -left-6 bg-[#111]/90 backdrop-blur-sm border border-[#ff5722]/30 rounded-2xl p-4 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[#ff5722] rounded-full flex items-center justify-center">
                    <span className="text-2xl font-bold text-white">{"🔥"}</span>
                  </div>
                  <div>
                    <p className="text-white font-semibold">1000+ Calories</p>
                    <p className="text-gray-400 text-sm">Burn per session</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-3 bg-[#ff5722] rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  )
}
