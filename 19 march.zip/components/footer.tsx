"use client"

import { Dumbbell, Facebook, Instagram, Twitter, Youtube } from 'lucide-react'

const footerLinks = {
  quickLinks: [
    { name: 'Home', href: '#home' },
    { name: 'Programs', href: '#programs' },
    { name: 'Schedule', href: '#schedule' },
    { name: 'Membership', href: '#membership' },
    { name: 'Contact', href: '#contact' },
  ],
  services: [
    { name: 'Personal Training', href: '#programs' },
    { name: 'Weight Loss', href: '#programs' },
    { name: 'Muscle Gain', href: '#programs' },
    { name: 'HIIT Classes', href: '#programs' },
    { name: 'Yoga & Wellness', href: '#programs' },
  ],
}

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Youtube, href: '#', label: 'YouTube' },
]

export default function Footer() {
  return (
    <footer className="bg-[#0a0a0a] border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <a href="#home" className="flex items-center gap-2 mb-6">
              <Dumbbell className="h-8 w-8 text-[#ff5722]" />
              <span className="text-2xl font-bold">
                <span className="text-[#ff5722]">PROJECT</span>
                <span className="text-white">FITNESS</span>
              </span>
            </a>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Transform your body and life at Lucknow&apos;s premier fitness destination. 
              Expert trainers, modern equipment, proven results.
            </p>
            {/* Social Links */}
            <div className="flex gap-4">
              {socialLinks.map((social, index) => (
                <a 
                  key={index}
                  href={social.href}
                  className="w-10 h-10 rounded-full bg-[#1a1a1a] flex items-center justify-center hover:bg-[#ff5722] transition-colors duration-300 group"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5 text-gray-400 group-hover:text-white" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {footerLinks.quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href}
                    className="text-gray-400 hover:text-[#ff5722] transition-colors duration-300"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold text-lg mb-6">Services</h4>
            <ul className="space-y-3">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href}
                    className="text-gray-400 hover:text-[#ff5722] transition-colors duration-300"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold text-lg mb-6">Contact Info</h4>
            <ul className="space-y-4">
              <li>
                <p className="text-gray-500 text-sm">Location</p>
                <p className="text-gray-300">Lucknow, Uttar Pradesh</p>
              </li>
              <li>
                <p className="text-gray-500 text-sm">Phone</p>
                <a href="tel:+919696384609" className="text-gray-300 hover:text-[#ff5722] transition-colors">
                  +91 9696384609
                </a>
              </li>
              <li>
                <p className="text-gray-500 text-sm">Email</p>
                <a href="mailto:techy.ai.oo1@gmail.com" className="text-gray-300 hover:text-[#ff5722] transition-colors">
                  techy.ai.oo1@gmail.com
                </a>
              </li>
              <li>
                <p className="text-gray-500 text-sm">Working Hours</p>
                <p className="text-gray-300">Mon - Sat: 5:00 AM - 10:00 PM</p>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} Project Fitness Gym. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-500 hover:text-[#ff5722] text-sm transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-500 hover:text-[#ff5722] text-sm transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
