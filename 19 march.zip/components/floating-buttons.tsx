"use client"

import { useState, useEffect } from 'react'
import { MessageCircle, X, ArrowUp, Phone } from 'lucide-react'

interface FloatingButtonsProps {
  onBookConsultation: () => void
}

export default function FloatingButtons({ onBookConsultation }: FloatingButtonsProps) {
  const [showScrollTop, setShowScrollTop] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const openWhatsApp = () => {
    const message = encodeURIComponent('Hi, I would like to know more about Project Fitness Gym.')
    window.open(`https://wa.me/919696384609?text=${message}`, '_blank')
  }

  return (
    <>
      {/* Sticky CTA Bar - Mobile */}
      <div className="fixed bottom-0 left-0 right-0 md:hidden bg-[#0a0a0a]/95 backdrop-blur-md border-t border-gray-800 p-4 z-50">
        <button
          onClick={onBookConsultation}
          className="w-full bg-[#ff5722] hover:bg-[#e64a19] text-white font-bold py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
        >
          <Phone className="w-5 h-5" />
          Book Free Consultation
        </button>
      </div>

      {/* Floating Buttons Container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 md:bottom-8 md:right-8 mb-20 md:mb-0">
        {/* Scroll to Top */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="w-12 h-12 bg-[#1a1a1a] border border-gray-700 rounded-full flex items-center justify-center hover:bg-[#252525] transition-all duration-300 shadow-lg animate-slide-up"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5 text-white" />
          </button>
        )}

        {/* Expanded Options */}
        {isExpanded && (
          <div className="flex flex-col gap-3 animate-slide-up">
            {/* Book Consultation - Desktop */}
            <button
              onClick={onBookConsultation}
              className="hidden md:flex items-center gap-3 bg-[#ff5722] text-white px-4 py-3 rounded-full shadow-lg hover:bg-[#e64a19] transition-all duration-300"
            >
              <Phone className="w-5 h-5" />
              <span className="font-semibold whitespace-nowrap">Book Consultation</span>
            </button>
          </div>
        )}

        {/* WhatsApp Button */}
        <button
          onClick={openWhatsApp}
          className="w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-all duration-300 animate-pulse-glow"
          aria-label="Chat on WhatsApp"
        >
          <svg viewBox="0 0 24 24" className="w-7 h-7 text-white fill-current">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
        </button>

        {/* Toggle Button */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="hidden md:flex w-14 h-14 bg-[#ff5722] rounded-full items-center justify-center shadow-lg hover:bg-[#e64a19] transition-all duration-300"
          aria-label={isExpanded ? 'Close menu' : 'Open menu'}
        >
          {isExpanded ? (
            <X className="w-6 h-6 text-white" />
          ) : (
            <MessageCircle className="w-6 h-6 text-white" />
          )}
        </button>

        {/* Chatbot Placeholder Label */}
        <div className="hidden">
          {/* Paste BotPenguin Chatbot Script Here */}
        </div>
      </div>
    </>
  )
}
