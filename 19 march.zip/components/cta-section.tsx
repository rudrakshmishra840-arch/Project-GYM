"use client"

import { Button } from '@/components/ui/button'
import { ArrowRight, Sparkles } from 'lucide-react'

interface CTASectionProps {
  onBookConsultation: () => void
}

export default function CTASection({ onBookConsultation }: CTASectionProps) {
  return (
    <section className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
          alt="Gym background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/80" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-[#ff5722] to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-[#ff5722] to-transparent" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-[#ff5722]/20 border border-[#ff5722]/30 rounded-full px-4 py-2 mb-8">
          <Sparkles className="w-4 h-4 text-[#ff5722]" />
          <span className="text-sm font-medium text-[#ff5722]">Limited Time Offer</span>
        </div>

        {/* Headline */}
        <h2 className="text-4xl lg:text-6xl font-bold text-white leading-tight mb-6">
          Start Your Fitness <br />
          <span className="text-gradient">Journey Today</span>
        </h2>

        <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
          Transform your body and life with expert guidance. Join 500+ satisfied members 
          who have already achieved their fitness goals with us.
        </p>

        {/* CTA Button */}
        <Button 
          onClick={onBookConsultation}
          className="bg-[#ff5722] hover:bg-[#e64a19] text-white font-bold px-10 py-7 text-xl rounded-full transition-all duration-300 hover:scale-105 hover:shadow-[0_0_40px_rgba(255,87,34,0.5)] animate-pulse-glow group"
        >
          Book Free Consultation
          <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-2 transition-transform" />
        </Button>

        {/* Trust Text */}
        <p className="mt-8 text-gray-500 text-sm">
          No commitment required • Free fitness assessment included
        </p>
      </div>
    </section>
  )
}
