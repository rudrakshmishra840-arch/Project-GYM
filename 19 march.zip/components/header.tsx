"use client"

import { useState, useEffect } from 'react'
import { Menu, X, Dumbbell } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface HeaderProps {
  onBookConsultation: () => void
}

export default function Header({ onBookConsultation }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Programs', href: '#programs' },
    { name: 'Schedule', href: '#schedule' },
    { name: 'Membership', href: '#membership' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' },
  ]

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-[#0a0a0a]/95 backdrop-blur-md shadow-lg' : 'bg-transparent'}`}>
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2 group">
            <div className="relative">
              <Dumbbell className="h-8 w-8 text-[#ff5722] transform group-hover:rotate-12 transition-transform duration-300" />
            </div>
            <span className="text-2xl font-bold tracking-tight">
              <span className="text-[#ff5722]">PROJECT</span>
              <span className="text-white">FITNESS</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-gray-300 hover:text-[#ff5722] transition-colors duration-300 text-sm font-medium uppercase tracking-wider"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Button 
              onClick={onBookConsultation}
              className="bg-[#ff5722] hover:bg-[#e64a19] text-white font-semibold px-6 py-2 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-[0_0_20px_rgba(255,87,34,0.5)]"
            >
              Join Now
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-20 left-0 right-0 bg-[#0a0a0a]/98 backdrop-blur-md border-t border-gray-800 animate-slide-up">
            <div className="px-4 py-6 space-y-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="block text-gray-300 hover:text-[#ff5722] transition-colors duration-300 text-lg font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <Button 
                onClick={() => {
                  setIsMenuOpen(false)
                  onBookConsultation()
                }}
                className="w-full bg-[#ff5722] hover:bg-[#e64a19] text-white font-semibold py-3 rounded-full mt-4"
              >
                Join Now
              </Button>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
