"use client"

import { CheckCircle, Users, Award, Dumbbell, TrendingUp } from 'lucide-react'

const trustItems = [
  { icon: Users, text: '500+ Happy Clients' },
  { icon: Award, text: 'Certified Trainers' },
  { icon: Dumbbell, text: 'Modern Equipment' },
  { icon: TrendingUp, text: 'Proven Results' },
]

export default function TrustBar() {
  return (
    <section className="bg-[#111] border-y border-[#ff5722]/20 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {trustItems.map((item, index) => (
            <div 
              key={index}
              className="flex items-center justify-center gap-3 group"
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#ff5722]/10 group-hover:bg-[#ff5722]/20 transition-colors duration-300">
                <CheckCircle className="w-5 h-5 text-[#ff5722]" />
              </div>
              <span className="text-white font-medium text-sm sm:text-base">{item.text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
