"use client"

import { useState, useEffect } from 'react'
import { X, ArrowRight, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ConsultationModalProps {
  isOpen: boolean
  onClose: () => void
}

const fitnessGoals = [
  'Weight Loss',
  'Muscle Gain',
  'General Fitness',
  'Strength Training',
  'Flexibility & Yoga',
]

export default function ConsultationModal({ isOpen, onClose }: ConsultationModalProps) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    goal: '',
  })
  const [showConfirmation, setShowConfirmation] = useState(false)

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
      setStep(1)
      setShowConfirmation(false)
    }
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [isOpen])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1)
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const handleSubmit = () => {
    setShowConfirmation(true)
  }

  const handleWhatsAppRedirect = () => {
    const message = encodeURIComponent(
      `Hi, I want to book a consultation.\n\nName: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\nGoal: ${formData.goal}`
    )
    window.open(`https://wa.me/919696384609?text=${message}`, '_blank')
    onClose()
    setFormData({ name: '', email: '', phone: '', goal: '' })
    setStep(1)
    setShowConfirmation(false)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-[#111] border border-gray-800 rounded-3xl w-full max-w-md overflow-hidden animate-slide-up">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-[#1a1a1a] flex items-center justify-center hover:bg-[#252525] transition-colors z-10"
          aria-label="Close modal"
        >
          <X className="w-5 h-5 text-gray-400" />
        </button>

        {/* Header */}
        <div className="bg-gradient-to-r from-[#ff5722] to-[#ff8a65] p-6 pb-8">
          <h2 className="text-2xl font-bold text-white">
            {showConfirmation ? 'Almost There!' : 'Book Free Consultation'}
          </h2>
          <p className="text-white/80 text-sm mt-1">
            {showConfirmation 
              ? 'Click below to send your details via WhatsApp'
              : 'Fill in your details to get started'}
          </p>
        </div>

        {/* Progress Steps */}
        {!showConfirmation && (
          <div className="flex justify-center gap-2 -mt-4 px-6">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all duration-300 ${
                  s === step 
                    ? 'bg-[#ff5722] text-white scale-110' 
                    : s < step 
                    ? 'bg-green-500 text-white'
                    : 'bg-[#1a1a1a] text-gray-500'
                }`}
              >
                {s < step ? <CheckCircle className="w-4 h-4" /> : s}
              </div>
            ))}
          </div>
        )}

        {/* Content */}
        <div className="p-6">
          {showConfirmation ? (
            <div className="text-center space-y-6">
              <div className="w-20 h-20 bg-[#ff5722]/20 rounded-full flex items-center justify-center mx-auto">
                <svg viewBox="0 0 24 24" className="w-10 h-10 text-[#25D366] fill-current">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <div>
                <p className="text-white text-lg mb-2">
                  By clicking, you will be redirected to WhatsApp.
                </p>
                <p className="text-gray-400 text-sm">
                  Just click send and our team will contact you within 24 hours.
                </p>
              </div>
              <Button
                onClick={handleWhatsAppRedirect}
                className="w-full bg-[#25D366] hover:bg-[#1da851] text-white font-bold py-4 rounded-xl"
              >
                Send via WhatsApp
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          ) : (
            <>
              {/* Step 1: Name */}
              {step === 1 && (
                <div className="space-y-4">
                  <label className="block">
                    <span className="text-gray-400 text-sm">What&apos;s your name?</span>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full mt-2 px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors"
                      placeholder="Enter your full name"
                      autoFocus
                    />
                  </label>
                </div>
              )}

              {/* Step 2: Contact */}
              {step === 2 && (
                <div className="space-y-4">
                  <label className="block">
                    <span className="text-gray-400 text-sm">Email Address</span>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full mt-2 px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors"
                      placeholder="your@email.com"
                      autoFocus
                    />
                  </label>
                  <label className="block">
                    <span className="text-gray-400 text-sm">Phone Number</span>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full mt-2 px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors"
                      placeholder="+91 9999999999"
                    />
                  </label>
                </div>
              )}

              {/* Step 3: Goal */}
              {step === 3 && (
                <div className="space-y-4">
                  <label className="block">
                    <span className="text-gray-400 text-sm">What&apos;s your fitness goal?</span>
                    <select
                      name="goal"
                      value={formData.goal}
                      onChange={handleChange}
                      className="w-full mt-2 px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors"
                    >
                      <option value="" disabled>Select your goal</option>
                      {fitnessGoals.map((goal) => (
                        <option key={goal} value={goal}>{goal}</option>
                      ))}
                    </select>
                  </label>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex gap-3 mt-6">
                {step > 1 && (
                  <Button
                    variant="outline"
                    onClick={handleBack}
                    className="flex-1 border-gray-700 text-white hover:bg-[#1a1a1a]"
                  >
                    Back
                  </Button>
                )}
                {step < 3 ? (
                  <Button
                    onClick={handleNext}
                    disabled={
                      (step === 1 && !formData.name) ||
                      (step === 2 && (!formData.email || !formData.phone))
                    }
                    className="flex-1 bg-[#ff5722] hover:bg-[#e64a19] text-white disabled:opacity-50"
                  >
                    Continue
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    disabled={!formData.goal}
                    className="flex-1 bg-[#ff5722] hover:bg-[#e64a19] text-white disabled:opacity-50"
                  >
                    Book Consultation
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
