"use client"

import { ArrowRight } from 'lucide-react'

const programs = [
  {
    title: 'Personal Training',
    description: 'One-on-one coaching tailored to your unique goals, schedules, and fitness level.',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=2070&auto=format&fit=crop',
  },
  {
    title: 'Strength Training',
    description: 'Build muscle, increase power, and transform your physique with expert guidance.',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c149a?q=80&w=2070&auto=format&fit=crop',
  },
  {
    title: 'HIIT Classes',
    description: 'High-intensity interval training that burns calories and builds endurance in record time.',
    image: 'https://images.unsplash.com/photo-1534258936925-c58bed479fcb?q=80&w=2031&auto=format&fit=crop',
  },
  {
    title: 'Fitness Training',
    description: 'Comprehensive fitness programs designed to improve overall health and wellness.',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?q=80&w=2070&auto=format&fit=crop',
  },
]

export default function ProgramsSection() {
  return (
    <section id="programs" className="py-20 lg:py-32 bg-[#0a0a0a] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
            Training Programs
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-white mt-4 mb-6">
            Our <span className="text-gradient">Programs</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Discover the perfect programs to match your goals and fitness level.
          </p>
        </div>

        {/* Programs Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {programs.map((program, index) => (
            <div 
              key={index}
              className="group relative overflow-hidden rounded-2xl h-80 cursor-pointer"
            >
              {/* Background Image */}
              <img 
                src={program.image}
                alt={program.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-80" />
              
              {/* Content */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <h3 className="text-2xl font-bold text-white mb-2 uppercase tracking-wide">
                  {program.title}
                </h3>
                <p className="text-gray-300 text-sm leading-relaxed max-w-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {program.description}
                </p>
                
                {/* Arrow Button */}
                <div className="absolute bottom-6 right-6 w-12 h-12 bg-[#ff5722] rounded-full flex items-center justify-center transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <ArrowRight className="w-5 h-5 text-white" />
                </div>
              </div>
              
              {/* Border Accent */}
              <div className="absolute bottom-0 left-0 w-full h-1 bg-[#ff5722] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
