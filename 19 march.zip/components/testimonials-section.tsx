"use client"

import { useState, useEffect } from 'react'
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react'

const testimonials = [
  {
    name: 'Rahul Sharma',
    role: 'Lost 15kg in 3 months',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    text: 'Great environment and quality equipment! The trainers at Project Fitness are incredibly knowledgeable and supportive. I never thought I could achieve my fitness goals until I joined here.',
  },
  {
    name: 'Priya Verma',
    role: 'Fitness Enthusiast',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    text: 'Supportive trainers and positive vibe throughout! Special thanks to the amazing trainers who push you to be your best while making sure you enjoy every workout.',
  },
  {
    name: 'Amit Singh',
    role: 'Gained 10kg muscle',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    text: 'Helpful trainers like Shoaib, Ankur, and Vishal have transformed my life. The personalized attention and expert guidance made all the difference in my transformation journey.',
  },
  {
    name: 'Sneha Gupta',
    role: 'Yoga & Fitness',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    text: 'The best gym in Lucknow! Clean facilities, modern equipment, and a supportive community. The yoga classes are exceptional and have improved my flexibility tremendously.',
  },
  {
    name: 'Vikram Patel',
    role: 'Weight Loss Journey',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    text: 'I was skeptical at first, but the results speak for themselves. Down 20kg and feeling stronger than ever. The diet guidance was a game-changer for me.',
  },
]

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  const nextTestimonial = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    setTimeout(() => setIsAnimating(false), 500)
  }

  const prevTestimonial = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
    setTimeout(() => setIsAnimating(false), 500)
  }

  useEffect(() => {
    const interval = setInterval(nextTestimonial, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-20 lg:py-32 bg-[#111] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-[#ff5722]/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
            Testimonials
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-white mt-4 mb-6">
            What Our <span className="text-gradient">Clients Say</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Real stories from real people who transformed their lives with us.
          </p>
        </div>

        {/* Testimonials Slider */}
        <div className="relative max-w-4xl mx-auto">
          {/* Quote Icon */}
          <Quote className="absolute -top-8 left-0 w-16 h-16 text-[#ff5722]/20" />
          
          {/* Main Testimonial Card */}
          <div className="bg-[#1a1a1a] rounded-3xl p-8 lg:p-12 border border-gray-800">
            <div className={`transition-all duration-500 ${isAnimating ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
              {/* Stars */}
              <div className="flex gap-1 mb-6">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-[#ff5722] fill-current" />
                ))}
              </div>

              {/* Text */}
              <p className="text-xl lg:text-2xl text-white leading-relaxed mb-8">
                {`"${testimonials[currentIndex].text}"`}
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <img 
                  src={testimonials[currentIndex].image}
                  alt={testimonials[currentIndex].name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-[#ff5722]"
                />
                <div>
                  <h4 className="text-white font-semibold text-lg">{testimonials[currentIndex].name}</h4>
                  <p className="text-[#ff5722] text-sm">{testimonials[currentIndex].role}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button 
              onClick={prevTestimonial}
              className="w-12 h-12 rounded-full bg-[#1a1a1a] border border-gray-700 flex items-center justify-center hover:bg-[#ff5722] hover:border-[#ff5722] transition-all duration-300 group"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5 text-gray-400 group-hover:text-white" />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex ? 'bg-[#ff5722] w-8' : 'bg-gray-600 hover:bg-gray-500'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <button 
              onClick={nextTestimonial}
              className="w-12 h-12 rounded-full bg-[#1a1a1a] border border-gray-700 flex items-center justify-center hover:bg-[#ff5722] hover:border-[#ff5722] transition-all duration-300 group"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
