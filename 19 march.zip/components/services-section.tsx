"use client"

import { Scale, Dumbbell, PersonStanding, Music, Flame, Sparkles } from 'lucide-react'

const services = [
  {
    icon: Scale,
    title: 'Weight Loss',
    description: 'Effective programs designed to help you shed pounds safely and sustainably with expert guidance.',
    color: 'from-red-500 to-orange-500',
  },
  {
    icon: Dumbbell,
    title: 'Muscle Gain',
    description: 'Build lean muscle mass with our scientifically-backed strength training programs.',
    color: 'from-orange-500 to-amber-500',
  },
  {
    icon: PersonStanding,
    title: 'Personal Training',
    description: 'One-on-one sessions with certified trainers tailored to your unique goals and fitness level.',
    color: 'from-amber-500 to-yellow-500',
  },
  {
    icon: Music,
    title: 'Zumba Classes',
    description: 'Fun, high-energy dance workouts that make burning calories feel like a party.',
    color: 'from-pink-500 to-rose-500',
  },
  {
    icon: Flame,
    title: 'HIIT Training',
    description: 'High-intensity interval training for maximum calorie burn in minimum time.',
    color: 'from-rose-500 to-red-500',
  },
  {
    icon: Sparkles,
    title: 'Yoga & Wellness',
    description: 'Find balance and flexibility with our yoga classes for mind-body harmony.',
    color: 'from-teal-500 to-cyan-500',
  },
]

export default function ServicesSection() {
  return (
    <section className="py-20 lg:py-32 bg-[#111] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-20 left-0 w-72 h-72 bg-[#ff5722]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-0 w-96 h-96 bg-[#ff5722]/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
            What We Offer
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-white mt-4 mb-6">
            Our <span className="text-gradient">Services</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Comprehensive fitness solutions designed to help you achieve your health and wellness goals.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group relative bg-[#1a1a1a] rounded-2xl p-8 border border-gray-800 hover:border-[#ff5722]/50 transition-all duration-500 hover:-translate-y-2"
            >
              {/* Gradient Background on Hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity duration-500`} />
              
              {/* Icon */}
              <div className="relative w-16 h-16 rounded-2xl bg-[#ff5722]/10 flex items-center justify-center mb-6 group-hover:bg-[#ff5722]/20 transition-colors duration-300">
                <service.icon className="w-8 h-8 text-[#ff5722]" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#ff5722] transition-colors duration-300">
                {service.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {service.description}
              </p>

              {/* Arrow */}
              <div className="mt-6 flex items-center gap-2 text-[#ff5722] opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="text-sm font-semibold">Learn More</span>
                <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
