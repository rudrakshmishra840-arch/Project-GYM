"use client"

import { useState } from 'react'

const categories = ['All Classes', 'Flexibility', 'Cardio', 'HIIT', 'Bodybuilding', 'CrossFit']

const scheduleData = [
  {
    day: 'Monday',
    classes: [
      { time: '6:00am - 7:30am', category: 'Cardio' },
      { time: '10:00am - 12:00pm', category: 'Flexibility' },
      { time: '2:00pm - 4:00pm', category: 'HIIT' },
      { time: '6:00pm - 8:00pm', category: 'Bodybuilding' },
    ]
  },
  {
    day: 'Tuesday',
    classes: [
      { time: '10:00am - 12:00pm', category: 'CrossFit' },
      { time: '2:00pm - 4:00pm', category: 'Cardio' },
      { time: '5:00pm - 7:00pm', category: 'HIIT' },
    ]
  },
  {
    day: 'Wednesday',
    classes: [
      { time: '6:00am - 8:00am', category: 'Flexibility' },
      { time: '10:00am - 12:00pm', category: 'Bodybuilding' },
      { time: '3:00pm - 5:00pm', category: 'Cardio' },
      { time: '6:00pm - 8:00pm', category: 'CrossFit' },
    ]
  },
  {
    day: 'Thursday',
    classes: [
      { time: '8:00am - 10:00am', category: 'HIIT' },
      { time: '12:00pm - 2:00pm', category: 'Flexibility' },
      { time: '4:00pm - 6:00pm', category: 'Bodybuilding' },
    ]
  },
  {
    day: 'Friday',
    classes: [
      { time: '6:00am - 8:00am', category: 'Cardio' },
      { time: '10:00am - 12:00pm', category: 'CrossFit' },
      { time: '2:00pm - 4:00pm', category: 'HIIT' },
      { time: '5:00pm - 7:00pm', category: 'Bodybuilding' },
    ]
  },
  {
    day: 'Saturday',
    classes: [
      { time: '9:00am - 11:00am', category: 'Flexibility' },
      { time: '12:00pm - 2:00pm', category: 'Cardio' },
      { time: '3:00pm - 5:00pm', category: 'CrossFit' },
    ]
  },
]

export default function ScheduleSection() {
  const [activeCategory, setActiveCategory] = useState('All Classes')

  const getFilteredClasses = (classes: typeof scheduleData[0]['classes']) => {
    if (activeCategory === 'All Classes') return classes
    return classes.filter(c => c.category === activeCategory)
  }

  return (
    <section id="schedule" className="py-20 lg:py-32 bg-[#111] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
            Class Timings
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-white mt-4 mb-6">
            Our <span className="text-gradient">Schedule</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Find the perfect time slot that fits your schedule.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-[#ff5722] text-white'
                  : 'bg-[#1a1a1a] text-gray-400 hover:text-white hover:bg-[#252525] border border-gray-700'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Schedule Table */}
        <div className="overflow-x-auto">
          <div className="min-w-[800px] bg-[#0a0a0a] rounded-2xl border border-gray-800 overflow-hidden">
            {/* Header */}
            <div className="grid grid-cols-5 bg-[#1a1a1a] border-b border-gray-800">
              <div className="p-4 text-center text-white font-semibold">Day</div>
              <div className="p-4 text-center text-white font-semibold col-span-4">Class Schedule</div>
            </div>
            
            {/* Rows */}
            {scheduleData.map((row, index) => {
              const filteredClasses = getFilteredClasses(row.classes)
              return (
                <div 
                  key={index}
                  className="grid grid-cols-5 border-b border-gray-800 last:border-b-0 hover:bg-[#111] transition-colors duration-300"
                >
                  <div className="p-4 flex items-center justify-center">
                    <span className="text-[#ff5722] font-semibold">{row.day}</span>
                  </div>
                  <div className="col-span-4 p-4 flex flex-wrap gap-3">
                    {filteredClasses.length > 0 ? (
                      filteredClasses.map((classItem, classIndex) => (
                        <div
                          key={classIndex}
                          className="bg-[#1a1a1a] px-4 py-2 rounded-lg border border-gray-700 hover:border-[#ff5722]/50 transition-colors duration-300"
                        >
                          <span className="text-white text-sm">{classItem.time}</span>
                          <span className="text-gray-500 text-xs block">{classItem.category}</span>
                        </div>
                      ))
                    ) : (
                      <span className="text-gray-500 text-sm">No classes scheduled</span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
