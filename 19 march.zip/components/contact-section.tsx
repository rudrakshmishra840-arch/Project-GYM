"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react'

const contactInfo = [
  {
    icon: MapPin,
    title: 'Location',
    details: 'Lucknow, Uttar Pradesh',
  },
  {
    icon: Phone,
    title: 'Phone',
    details: '+91 9696384609',
  },
  {
    icon: Mail,
    title: 'Email',
    details: 'techy.ai.oo1@gmail.com',
  },
  {
    icon: Clock,
    title: 'Hours',
    details: 'Mon - Sat: 5AM - 10PM',
  },
]

const fitnessGoals = [
  'Weight Loss',
  'Muscle Gain',
  'General Fitness',
  'Strength Training',
  'Flexibility & Yoga',
]

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    goal: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Create WhatsApp message
    const message = encodeURIComponent(
      `Hi, I want to book a consultation.\n\nName: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\nGoal: ${formData.goal}`
    )

    // Redirect to WhatsApp
    window.open(`https://wa.me/919696384609?text=${message}`, '_blank')

    // Reset form after a delay
    setTimeout(() => {
      setIsSubmitting(false)
      setFormData({ name: '', email: '', phone: '', goal: '' })
    }, 1000)
  }

  return (
    <section id="contact" className="py-20 lg:py-32 bg-[#111] relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#ff5722]/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-[#ff5722] font-semibold uppercase tracking-wider text-sm">
            Get In Touch
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-white mt-4 mb-6">
            Contact <span className="text-gradient">Us</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Ready to start your fitness journey? Reach out to us and we will get back to you within 24 hours.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div className="space-y-8">
            <div className="grid sm:grid-cols-2 gap-6">
              {contactInfo.map((info, index) => (
                <div 
                  key={index}
                  className="bg-[#1a1a1a] rounded-2xl p-6 border border-gray-800 hover:border-[#ff5722]/50 transition-colors duration-300"
                >
                  <div className="w-12 h-12 rounded-xl bg-[#ff5722]/10 flex items-center justify-center mb-4">
                    <info.icon className="w-6 h-6 text-[#ff5722]" />
                  </div>
                  <h4 className="text-white font-semibold mb-1">{info.title}</h4>
                  <p className="text-gray-400 text-sm">{info.details}</p>
                </div>
              ))}
            </div>

            {/* Map Placeholder */}
            <div className="bg-[#1a1a1a] rounded-2xl h-64 border border-gray-800 overflow-hidden">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227749.04263173014!2d80.7787808!3d26.8498209!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd991f32b16b%3A0x93ccba8909978be7!2sLucknow%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1699999999999!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'grayscale(100%) invert(92%) contrast(83%)' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Project Fitness Gym Location"
              />
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-[#1a1a1a] rounded-3xl p-8 lg:p-10 border border-gray-800">
            <h3 className="text-2xl font-bold text-white mb-6">Book Your Free Consultation</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-2">
                  Full Name
                </label>
                <input 
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#111] border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors duration-300"
                  placeholder="Enter your full name"
                />
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">
                  Email Address
                </label>
                <input 
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#111] border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors duration-300"
                  placeholder="Enter your email"
                />
              </div>

              {/* Phone */}
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-400 mb-2">
                  Phone Number
                </label>
                <input 
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#111] border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors duration-300"
                  placeholder="Enter your phone number"
                />
              </div>

              {/* Fitness Goal */}
              <div>
                <label htmlFor="goal" className="block text-sm font-medium text-gray-400 mb-2">
                  Fitness Goal
                </label>
                <select 
                  id="goal"
                  name="goal"
                  value={formData.goal}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#111] border border-gray-700 rounded-xl text-white focus:border-[#ff5722] focus:ring-1 focus:ring-[#ff5722] transition-colors duration-300"
                >
                  <option value="" disabled>Select your fitness goal</option>
                  {fitnessGoals.map((goal, index) => (
                    <option key={index} value={goal}>{goal}</option>
                  ))}
                </select>
              </div>

              {/* Submit Button */}
              <Button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#ff5722] hover:bg-[#e64a19] text-white font-bold py-4 rounded-xl transition-all duration-300 hover:shadow-[0_0_20px_rgba(255,87,34,0.5)] disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    Processing...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <Send className="w-5 h-5" />
                    Book Consultation via WhatsApp
                  </span>
                )}
              </Button>

              <p className="text-gray-500 text-xs text-center">
                By clicking, you will be redirected to WhatsApp. Just click send and our team will contact you within 24 hours.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
