"use client"

import { useState, useEffect } from 'react'
import Header from '@/components/header'
import HeroSection from '@/components/hero-section'
import TrustBar from '@/components/trust-bar'
import AboutSection from '@/components/about-section'
import ServicesSection from '@/components/services-section'
import ProgramsSection from '@/components/programs-section'
import ScheduleSection from '@/components/schedule-section'

import TestimonialsSection from '@/components/testimonials-section'
import TrainersSection from '@/components/trainers-section'
import CTASection from '@/components/cta-section'
import ContactSection from '@/components/contact-section'
import Footer from '@/components/footer'
import FloatingButtons from '@/components/floating-buttons'
import ConsultationModal from '@/components/consultation-modal'

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const openModal = () => setIsModalOpen(true)
  const closeModal = () => setIsModalOpen(false)

  return (
    <main className={`min-h-screen bg-[#0a0a0a] transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
      <Header onBookConsultation={openModal} />
      <HeroSection onBookConsultation={openModal} />
      <TrustBar />
      <AboutSection />
      <ServicesSection />
      <ProgramsSection />
      <ScheduleSection />
      
      <TestimonialsSection />
      <TrainersSection />
      <CTASection onBookConsultation={openModal} />
      <ContactSection />
      <Footer />
      <FloatingButtons onBookConsultation={openModal} />
      <ConsultationModal isOpen={isModalOpen} onClose={closeModal} />
      
      {/* BotPenguin Chatbot Placeholder */}
      {/* Paste BotPenguin Chatbot Script Here */}
    </main>
  )
}
