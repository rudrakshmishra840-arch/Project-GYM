import type { Metadata } from 'next'
import { Oswald, Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const oswald = Oswald({ 
  subsets: ["latin"],
  variable: '--font-oswald',
  weight: ['400', '500', '600', '700']
});

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter'
});

export const metadata: Metadata = {
  title: 'Project Fitness Gym | Transform Your Body, Transform Your Life',
  description: 'Join Project Fitness Gym in Lucknow with certified trainers & personalized plans. Weight loss, muscle gain, personal training, Zumba, HIIT & Yoga classes available.',
  keywords: ['gym', 'fitness', 'Lucknow', 'personal training', 'weight loss', 'muscle gain', 'HIIT', 'Zumba', 'Yoga'],
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${oswald.variable} ${inter.variable}`}>
      <body className="font-sans antialiased bg-[#0a0a0a] text-white">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
